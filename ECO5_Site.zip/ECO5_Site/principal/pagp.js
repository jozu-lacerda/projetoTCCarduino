let indexAtual = 0;

function moverCarrossel(n) {
    indexAtual += n;
    mostrarImagem(indexAtual);
}

function mostrarImagem(index) {
    const carrossel = document.querySelector('.carrossel');
    const itens = document.querySelectorAll('.carrossel-item');
    const totalItens = itens.length;

    if (index >= totalItens) {
        indexAtual = 0;
    } else if (index < 0) {
        indexAtual = totalItens - 1;
    }

    carrossel.style.transform = 'translateX(' + (-indexAtual * 100) + '%)';
}


setInterval(() => {
    moverCarrossel(1);
}, 3000); 
